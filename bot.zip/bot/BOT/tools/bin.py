import httpx
import pycountry
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *

async def singlebinget(message):
    try:
        parts = message.text.split()
        if len(parts) >= 2:
            return parts[1], None, None, None
        else:
            return False
    except:
        return False

async def get_bin_info_from_api(fbin):
    try:
        # Make a GET request to the Raven BIN Lookup API
        url = f"https://cheker.site/bins/?bin={fbin}"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()  # Raise an exception for HTTP errors
            data = response.json()

            # Check if the API returned a successful response
            if data.get("status") == "success":
                bin_data = data.get("data", {})
                return {
                    "bin": bin_data.get("bin", "N/A"),
                    "brand": bin_data.get("brand", "N/A"),
                    "type": bin_data.get("type", "N/A"),
                    "category": bin_data.get("category", "N/A"),
                    "issuer": bin_data.get("issuer", {}).get("name", "N/A"),
                    "country": {
                        "name": bin_data.get("country", {}).get("name", "N/A"),
                        "alpha2": bin_data.get("country", {}).get("alpha2", "N/A"),
                        "flag": bin_data.get("country", {}).get("flag", "N/A"),
                    }
                }
            else:
                return {}
    except Exception as e:
        print(f"Error fetching BIN info from API: {e}")
        return {}

def get_country_name(code, fallback_country_name):
    try:
        country = pycountry.countries.get(alpha_2=code)
        return country.name if country else fallback_country_name
    except Exception as e:
        print(f"Error getting country name: {e}")
        return fallback_country_name

@Client.on_message(filters.command("bin", [".", "/"]))
async def cmd_bin(client, message):
    try:
        checkall = await check_all_thing(client, message)
        if checkall[0] == False:
            return

        bin = await singlebinget(message)
        if bin == False:
            bin = await getmessage(message)
            if bin == False:
                resp = """
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐁𝐈𝐍 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨 𝐕𝐚𝐥𝐢𝐝 𝐁𝐈𝐍 𝐰𝐚𝐬 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 𝐲𝐨𝐮𝐫 𝐢𝐧𝐩𝐮𝐭.
"""
                await message.reply_text(resp, quote=True)
                return

        fbin = bin[0][:6]
        bin_info = await get_bin_info_from_api(fbin)

        if not bin_info:
            resp = """
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐁𝐈𝐍 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨 𝐕𝐚𝐥𝐢𝐝 𝐁𝐈𝐍 𝐢𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 𝐭𝐡𝐞 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞.
"""
            await message.reply_text(resp, quote=True)
            return

        brand = bin_info.get("brand", "N/A").upper()
        card_type = bin_info.get("type", "N/A").upper()
        category = bin_info.get("category", "N/A").upper()
        issuer = bin_info.get("issuer", "N/A").upper()
        country_name = bin_info.get("country", {}).get("name", "N/A").upper()
        country_flag = bin_info.get("country", {}).get("flag", "N/A")

        resp = f"""
𝗕𝗜𝗡 𝗟𝗼𝗼𝗸𝘂𝗽 𝗥𝗲𝘀𝘂𝗹𝘁 🔍

𝗕𝗜𝗡: <code>{fbin}</code>
𝗜𝗻𝗳𝗼: <code>{brand} - {card_type} - {category}</code>
𝐁𝐚𝐧𝐤: <code>{issuer} 🏛</code>
𝐂𝐨𝐮𝐧𝐭𝐫𝐲: <code>{country_name} {country_flag}</code>
"""
        await message.reply_text(resp, quote=True)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())