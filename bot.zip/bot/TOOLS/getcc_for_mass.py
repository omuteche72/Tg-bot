from FUNC.defs import *
import re


async def getcc_for_mass(message, role):
    try:
        ccs = []

        # Check if the message or reply contains text
        if message.reply_to_message:
            text = message.reply_to_message.text
        else:
            text = message.text

        # If text is None, return an error response
        if text is None:
            resp = """<b>
No Input Found ⚠️

Message: Please Provide CC Details or Reply to a Message Containing CC Details.
</b>"""
            return False, resp

        # Process each line in the text
        for i in text.split("\n"):
            get = await getcards(i)
            if get is not None:
                cc = get[0]
                mes = get[1]
                ano = get[2]
                cvv = get[3]
                fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                ccs.append(fullcc)

        # Check limits based on user role
        if role == "FREE" and len(ccs) > 16:
            resp = """<b>
Limit Reached ⚠️

Message: You Can Check 15 CC at a Time. Buy Plan to Increase Your Limit.

Type /buy For Paid Plan
</b>"""
            return False, resp

        if (role == "PREMIUM" or role == "LIFETIME") and len(ccs) > 25:
            resp = """<b>
Limit Reached ⚠️

Message: You Can Check 25 CC at a Time. If You Need a Higher Limit, Contact @omuteche.

Type /buy For Paid Plan
</b>"""
            return False, resp

        if len(ccs) == 0:
            resp = """<b>
CC Not Found ⚠️

Message: We Are Unable to Find Any CC Details From Your Input. Provide CC's Details To Check.
</b>"""
            return False, resp

        # Return the list of valid CCs
        return True, ccs

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
        return False, "An Error Occurred. Please Try Again Later."
